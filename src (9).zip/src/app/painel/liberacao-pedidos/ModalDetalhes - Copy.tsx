"use client";

import { useState } from "react";

interface Produto {
  produto_nome: string;
  tratamento?: string;
  quantidade: number;
  valor_unitario: number;
  status_produto?: string;
  motivo_reprovacao?: string;
}

interface Pedido {
  id: number;
  cliente_nome: string;
  cliente_codigo: string;
  frete: string;
  vl_primeira_parc: number;
  vl_segunda_parc: number;
  produtos: Produto[];
  obs_vendedor?: string;
  cnpj?: string;
  mes_primeiro_pgto?: number;
  mes_segundo_pgto?: number;
}

interface Props {
  pedido: Pedido;
  onClose: () => void;
}

export default function ModalDetalhes({ pedido, onClose }: Props) {
  const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  const total = (pedido.produtos || []).reduce((s, p) => s + p.valor_unitario * p.quantidade, 0);

  const [produtosState, setProdutosState] = useState<Produto[]>(pedido.produtos);
  const [statusProdutos, setStatusProdutos] = useState<{ status?: string; loading?: boolean }[]>([]);
  const [motivoReprovacao, setMotivoReprovacao] = useState<string[]>([]);
  const [mostrarMotivo, setMostrarMotivo] = useState<number | null>(null);
  const [acaoAtual, setAcaoAtual] = useState<string[]>([]);
  const algumPendente = produtosState.some((p) => !p.status_produto);

  const handleAcaoProduto = async (idx: number, status: "aprovado" | "reprovado") => {
    const produto = produtosState[idx];
    const payload = {
      id_pedido: pedido.id,
      item: idx + 1,
      status,
      produto_codigo: produto.produto_nome,
      mensagem: status === "reprovado" ? motivoReprovacao[idx] : ""
    };

    setStatusProdutos((prev) => {
      const copia = [...prev];
      copia[idx] = { loading: true };
      return copia;
    });

    setAcaoAtual((prev) => {
      const copia = [...prev];
      copia[idx] = status;
      return copia;
    });

    try {
      const response = await fetch("/api/pedidos-aprovacao", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error("Erro ao registrar");

      setStatusProdutos((prev) => {
        const copia = [...prev];
        copia[idx] = { status };
        return copia;
      });

      setProdutosState((prev) => {
        const copia = [...prev];
        copia[idx] = { ...copia[idx], status_produto: status };
        return copia;
      });

      window.dispatchEvent(new Event("refreshPedidos"));
    } catch (err) {
      console.error("Erro ao enviar ação:", err);
      alert("Erro ao registrar aprovação/reprovação. Tente novamente.");
      setStatusProdutos((prev) => {
        const copia = [...prev];
        copia[idx] = {};
        return copia;
      });
    }
  };

  const abrirMotivo = (idx: number) => setMostrarMotivo(idx);
  const confirmarMotivo = (idx: number) => {
    setMostrarMotivo(null);
    handleAcaoProduto(idx, "reprovado");
  };

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100%", height: "100%",
      backgroundColor: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1000
    }}>
      <div style={{
        backgroundColor: "#fff", borderRadius: "12px", width: "90%", maxWidth: "900px",
        maxHeight: "90vh", overflowY: "auto", boxShadow: "0 4px 12px rgba(0,0,0,0.3)"
      }}>
        <div style={{
          background: "linear-gradient(to right, #1e4321, #47763b)", color: "white",
          padding: "1rem 1.5rem", borderTopLeftRadius: "12px", borderTopRightRadius: "12px",
          display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
          <h5 style={{ margin: 0 }}>Detalhes do Pedido</h5>
          <button onClick={() => {
            if (algumPendente) {
              alert("Você precisa aprovar ou reprovar todos os itens antes de fechar.");
              return;
            }
            onClose();
          }} style={{
            background: "none", border: "none", fontSize: "1.5rem", color: "white", cursor: "pointer"
          }}>×</button>
        </div>

        <div style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
          {/* Cliente */}
          <div style={{ border: "1px solid #28a745", borderRadius: "10px", padding: "1rem" }}>
            <p><strong>👤 Cliente:</strong> {pedido.cliente_nome} ({pedido.cliente_codigo})</p>
            {pedido.cnpj && <p><strong>🧾 CNPJ/CPF:</strong> {pedido.cnpj}</p>}
            <p><strong>🚚 Frete:</strong> {pedido.frete}</p>
          </div>

          {/* Pagamento */}
          <div style={{ border: "1px solid #28a745", borderRadius: "10px", padding: "1rem" }}>
            <p><strong>💰 Pagamento:</strong></p>
            {pedido.vl_segunda_parc === 0 ? (
              <p>• Parcela Única: {pedido.vl_primeira_parc.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} {pedido.mes_primeiro_pgto ? `em ${meses[pedido.mes_primeiro_pgto - 1]}` : ""}</p>
            ) : (
              <>
                <p>1ª Parcela: {pedido.vl_primeira_parc.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} {pedido.mes_primeiro_pgto ? `em ${meses[pedido.mes_primeiro_pgto - 1]}` : ""}</p>
                <p>2ª Parcela: {pedido.vl_segunda_parc.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} {pedido.mes_segundo_pgto ? `em ${meses[pedido.mes_segundo_pgto - 1]}` : ""}</p>
              </>
            )}
            <p style={{ fontWeight: "bold", color: "#1e4321", marginTop: "1rem" }}>
              • 🟢 Total do Pedido: {total.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </p>
          </div>

          {/* Produtos */}
          <div style={{ border: "1px solid #28a745", borderRadius: "10px", padding: "1rem" }}>
            <p><strong>📦 Produtos:</strong></p>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "linear-gradient(to right, #2f5a32, #1e4321)", color: "white" }}>
                <tr>
                  <th style={{ padding: "10px", border: "1px solid #1e4321" }}>Produto</th>
                  <th style={{ padding: "10px", border: "1px solid #1e4321" }}>Qtd</th>
                  <th style={{ padding: "10px", border: "1px solid #1e4321" }}>Valor Unit</th>
                  <th style={{ padding: "10px", border: "1px solid #1e4321" }}>Ação</th>
                </tr>
              </thead>
              <tbody>
                {produtosState.map((p, idx) => {
                  const status = p.status_produto || 'pendente';
                  return (
                    <tr key={idx}>
                      <td style={{ padding: "8px" }}>{p.produto_nome} {p.tratamento && `(${p.tratamento})`}</td>
                      <td style={{ padding: "8px" }}>{p.quantidade}</td>
                      <td style={{ padding: "8px" }}>{p.valor_unitario.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</td>
                      <td style={{ padding: "8px" }}>
                        {status === "aprovado" ? (
                          <button disabled style={{ backgroundColor: "#d4edda", color: "#155724", padding: "6px 10px", borderRadius: "4px", border: "none" }}>✅ Aprovado</button>
                        ) : status === "reprovado" ? (
                          <>
                            <button disabled style={{ backgroundColor: "#f8d7da", color: "#721c24", padding: "6px 10px", borderRadius: "4px", border: "none" }}>❌ Reprovado</button>
                            {p.motivo_reprovacao && (
                              <div style={{ fontSize: "0.8rem", marginTop: "4px", color: "#721c24" }}>
                                <strong>Motivo:</strong> {p.motivo_reprovacao}
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            <button
                              disabled={statusProdutos[idx]?.loading}
                              onClick={() => handleAcaoProduto(idx, "aprovado")}
                              style={{ marginRight: "6px" }}
                            >
                              {statusProdutos[idx]?.loading && acaoAtual[idx] === "aprovado" ? "⏳" : "✔️"}
                            </button>
                            <button
                              disabled={statusProdutos[idx]?.loading}
                              onClick={() => abrirMotivo(idx)}
                            >
                              {statusProdutos[idx]?.loading && acaoAtual[idx] === "reprovado" ? "⏳" : "❌"}
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {mostrarMotivo !== null && (
              <div style={{ marginTop: "1rem" }}>
                <label>Motivo da Reprovação:</label>
                <textarea
                  style={{ width: "100%", minHeight: "60px", padding: "8px", borderRadius: "6px", border: "1px solid #ccc" }}
                  value={motivoReprovacao[mostrarMotivo] || ""}
                  onChange={(e) => {
                    const nova = [...motivoReprovacao];
                    nova[mostrarMotivo] = e.target.value;
                    setMotivoReprovacao(nova);
                  }}
                />
                <button onClick={() => confirmarMotivo(mostrarMotivo)} style={{ marginTop: "8px", padding: "6px 12px", backgroundColor: "#dc3545", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>
                  Enviar Reprovação
                </button>
              </div>
            )}
          </div>

          {/* Observações */}
          <div style={{ border: "1px solid #28a745", borderRadius: "10px", padding: "1rem" }}>
            <strong style={{ color: "#1e4321" }}>📝 Observação do Vendedor:</strong>
            <p style={{ marginTop: "0.5rem" }}>{pedido.obs_vendedor?.trim() || "Nenhuma observação registrada."}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
