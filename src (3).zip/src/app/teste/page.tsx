export const dynamic = 'force-dynamic';

export default function TestePage() {
  return <div style={{ padding: 40 }}>✅ Página teste renderizada com sucesso!</div>;
}