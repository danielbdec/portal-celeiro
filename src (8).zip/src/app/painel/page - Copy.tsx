"use client";

import { useSession } from "next-auth/react";
import { Spin } from "antd";
import { LoadingOutlined } from "@ant-design/icons";
import { useState } from "react";

export default function HomePage() {
  const { data: session, status } = useSession();
  const [loadingLogout, setLoadingLogout] = useState(false);
  const greenSpinner = <LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />;

  if (status === "loading" || loadingLogout) {
    return (
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 9999,
        background: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <Spin tip={loadingLogout ? "Saindo..." : "Carregando..."} indicator={greenSpinner} />
      </div>
    );
  }

  return (
    <div style={{ padding: "2rem", maxWidth: "700px" }}>
      <div style={{
        backgroundColor: "#fff",
        borderRadius: "12px",
        padding: "2rem",
        boxShadow: "0 6px 18px rgba(0,0,0,0.12)"
      }}>
        <h1 style={{
          fontSize: "1.75rem",
          fontWeight: "bold",
          background: "linear-gradient(90deg, #1e4321, #8dc891)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          display: "inline-flex",
          alignItems: "center",
          gap: "8px",
          marginBottom: "1.5rem"
        }}>
          🏠 Bem-vindo, {session?.user?.name}
        </h1>

        <p style={{ fontSize: "1rem", color: "#444", marginBottom: "1.5rem" }}>
          Seu e-mail: <strong>{session?.user?.email}</strong>
        </p>

        <button
          onClick={() => {
            setLoadingLogout(true);
            window.location.href =
              "https://login.microsoftonline.com/common/oauth2/v2.0/logout?post_logout_redirect_uri=http://localhost:3000/login";
          }}
          style={{
            backgroundColor: "#8dc891",
            border: "none",
            color: "#fff",
            padding: "0.5rem 1.5rem",
            borderRadius: "20px",
            fontWeight: "bold",
            cursor: "pointer",
            fontSize: "1rem",
            transition: "0.2s ease-in-out",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
          }}
        >
          Sair
        </button>
      </div>
    </div>
  );
}
