"use client";

import { useSession, signOut } from "next-auth/react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Spin } from "antd";
import {
  House,
  Notebook,
  Users,
  ShieldUser,
  SquareCheckBig,
  UserPlus,
  Contact2,
  LogOut,
  ArrowBigLeft,
  ArrowBigRight,
  BookUser,
  DollarSign,
} from "lucide-react";
import { LoadingOutlined } from "@ant-design/icons";

import ChatWidget from "../components/ChatWidget";

import "@refinedev/antd/dist/reset.css";
import "./globals.css";
import "./custom-sidebar.css";

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [loadingLogout, setLoadingLogout] = useState(false);
  const router = useRouter();
  const { data: session, status } = useSession();

  console.log("PERFIL ATUAL:", session?.user?.perfil);

  useEffect(() => {
    if (typeof window !== "undefined" && window.innerWidth < 768) {
      setCollapsed(true);
    }
  }, []);

  const greenSpinner = <LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />;

  if (status === "loading" || loadingLogout) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
        <Spin tip={loadingLogout ? "Saindo..." : "Carregando..."} indicator={greenSpinner} />
      </div>
    );
  }

  const getSelectedKey = () => {
    if (!pathname) return undefined;

    if (pathname.startsWith("/painel/perfil")) return "perfil";
    if (pathname.startsWith("/painel/relatorios/meus-pedidos")) return "meus-pedidos";
    if (pathname.startsWith("/painel/relatorios")) return "relatorios";
    if (pathname.startsWith("/painel/cadastro-usuarios")) return "cadastro-usuarios";
    if (pathname.startsWith("/painel/liberacao-pedidos")) return "liberacao";
    if (pathname.startsWith("/painel/cadastro-cliente")) return "cadastro-cliente";
    if (pathname.startsWith("/painel/cadastro-contato")) return "cadastro-contato";
    if (pathname.startsWith("/painel/cadastro-area")) return "cadastro-area";
    return undefined;
  };

  const perfil = (session?.user?.perfil || "").toLowerCase().trim();

  const menuItems: any[] = [
    {
      key: "inicio",
      icon: <House size={18} color="white" />,
      label: "Início",
      onClick: () => router.push("/painel"),
    },
    {
      key: "perfil",
      icon: <ShieldUser size={18} color="white" />,
      label: "Meu Perfil",
      onClick: () => router.push("/painel/perfil"),
    },
    {
      key: "cadastro",
      icon: <UserPlus size={18} color="white" />,
      label: "Cadastros",
      children: [
        {
          key: "cadastro-cliente",
          icon: <UserPlus size={18} color="white" />,
          label: "Clientes",
          onClick: () => router.push("/painel/cadastro-cliente"),
        },
        {
          key: "cadastro-contato",
          icon: <Contact2 size={18} color="white" />,
          label: "Contatos",
          onClick: () => router.push("/painel/cadastro-contato"),
        },
        {
          key: "cadastro-area",
          icon: <SquareCheckBig size={18} color="white" />,
          label: "Áreas",
          onClick: () => router.push("/painel/cadastro-area"),
        },
      ],
    },
    {
      key: "relatorios",
      icon: <Notebook size={18} color="white" />,
      label: "Relatórios",
      children: [
        {
          key: "meus-pedidos",
          icon: <BookUser size={18} color="white" />,
          label: "Pedidos",
          onClick: () => router.push("/painel/relatorios/meus-pedidos"),
        },
      ],
    },
  ,
  {
    key: "credito",
    icon: <DollarSign size={18} color="white" />,
    label: "Crédito",
    children: [
      {
        key: "cadastro-cred-cli",
        icon: <UserPlus size={18} color="white" />,
        label: "Clientes",
        onClick: () => router.push("/painel/cadastro-cred-cli"),
      },
    ],
  },
];

  if (perfil === "admin") {
    menuItems.push({
      key: "cadastro-usuarios",
      icon: <Users size={18} color="white" />,
      label: "Usuários",
      onClick: () => router.push("/painel/cadastro-usuarios"),
    });
  }

  if (["aprovador", "admin"].includes(perfil)) {
    menuItems.push({
      key: "liberacao",
      icon: <SquareCheckBig size={18} color="white" />,
      label: "Liberação",
      onClick: () => router.push("/painel/liberacao-pedidos"),
    });
  }

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <div
        style={{
          width: collapsed ? 80 : 170,
          transition: "width 0.2s",
          background: "linear-gradient(to bottom, var(--cor-sidebar-gradiente-topo), var(--cor-sidebar-gradiente-base))",
          padding: "1rem 0.5rem",
          color: "white",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        <div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              paddingLeft: collapsed ? 0 : 16,
              paddingRight: collapsed ? 0 : 16,
            }}
          >
            <img
              src="/logo.png"
              alt="Logo"
              style={{
                width: collapsed ? 95 : 140,
                objectFit: "contain",
                transition: "all 0.2s ease-in-out",
                transform: collapsed ? "translateX(15px)" : "none"
              }}
            />

            <div
              onClick={() => setCollapsed(!collapsed)}
              style={{
                cursor: "pointer",
                color: "white",
                fontSize: "13px",
                display: "flex",
                alignItems: "center",
                justifyContent: collapsed ? "center" : "flex-start",
                height: 45,
                width: "100%",
                paddingLeft: collapsed ? 0 : 4,
                marginTop: 13,
                marginBottom: 12
              }}
            >
              {collapsed ? <ArrowBigRight size={25} /> : <ArrowBigLeft size={25} />}
            </div>
          </div>

          <Menu
            mode="inline"
            inlineCollapsed={collapsed}
            selectedKeys={getSelectedKey() ? [getSelectedKey() as string] : []}
            style={{ background: "transparent", borderRight: 0 }}
            items={menuItems}
          />
        </div>

        <div
          onClick={async () => {
            setLoadingLogout(true);
            await signOut({ redirect: false });
            router.push("/login");
          }}
          style={{ color: "white", cursor: "pointer", padding: "0.5rem 1rem" }}
        >
          <LogOut size={18} /> {collapsed ? "" : "Sair"}
        </div>
      </div>
      <main style={{ flex: 1, overflow: "auto", padding: "1rem", position: "relative" }}>
        {children}
        <ChatWidget />
      </main>
    </div>
  );
}
