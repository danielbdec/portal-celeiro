// pages/api/viacep.ts
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { cep } = req.query;

  if (!cep || typeof cep !== 'string') {
    return res.status(400).json({ erro: true, message: 'CEP inválido' });
  }

  try {
    const viaCep = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
    if (viaCep.data.erro) throw new Error();

    return res.status(200).json(viaCep.data);
  } catch {
    try {
      const fallback = await axios.get(`https://api.awesomeapi.com.br/cep/json/${cep}`);
      return res.status(200).json({
        logradouro: fallback.data.address,
        bairro: fallback.data.district,
        localidade: fallback.data.city,
        uf: fallback.data.state,
        ibge: fallback.data.city_ibge_code,
      });
    } catch {
      return res.status(500).json({ erro: true, message: 'Erro ao consultar o CEP em ambos os serviços.' });
    }
  }
}
