"use client";

import { useSession } from "next-auth/react";
import { Button, Spin } from "antd";
import { LoadingOutlined } from "@ant-design/icons";
import { useState } from "react";

export default function HomePage() {
  const { data: session, status } = useSession();
  const [loadingLogout, setLoadingLogout] = useState(false);
  const greenSpinner = <LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />;

  if (status === "loading" || loadingLogout) {
    return (
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 9999,
        background: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <Spin tip={loadingLogout ? "Saindo..." : "Carregando..."} indicator={greenSpinner} />
      </div>
    );
  }

  return (
    <div style={{ padding: "2rem" }}>
      <div
        style={{
          background: "#fff",
          padding: "2rem",
          borderRadius: "16px",
          boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
          maxWidth: "640px",
        }}
      >
        <h1
          style={{
            fontSize: "1.75rem",
            fontWeight: "bold",
            marginBottom: "1.5rem",
            background: "linear-gradient(90deg, #1e4321, #9ad6a3)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
          }}
        >
          🏠 Bem-vindo, {session?.user?.name}
        </h1>

        <p style={{ marginBottom: "2rem", color: "#444", fontSize: "1rem" }}>
          Seu e-mail: <strong>{session?.user?.email}</strong>
        </p>

        <Button
          onClick={() => {
            setLoadingLogout(true);
            window.location.href =
              "https://login.microsoftonline.com/common/oauth2/v2.0/logout?post_logout_redirect_uri=http://localhost:3000/login";
          }}
          style={{
            backgroundColor: "#8dc891",
            borderColor: "#8dc891",
            color: "white",
            borderRadius: "20px",
            padding: "0.5rem 1.5rem",
            fontWeight: "bold",
          }}
        >
          Sair
        </Button>
      </div>
    </div>
  );
}
